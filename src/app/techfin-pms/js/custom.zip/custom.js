document.addEventListener('DOMContentLoaded', function () {
  const sideTabBtns = document.querySelectorAll('.sidebar-tab-btn');
  const sideTabConts = document.querySelectorAll('.sidebar-content');

  sideTabBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const target = document.querySelector(`.${btn.getAttribute(['data-target'])}`);
      sideTabBtns.forEach((item) => item.classList.remove('ac--active'));
      btn.classList.add('ac--active');

      sideTabConts.forEach((item) => (item.style.cssText = 'display:none'));
      target.style.cssText = 'display:flex';
    });
  });

  // sidebar fold
  const foldRoot = document.querySelector('.console-container');
  const foldBtn = document.querySelector('.sidebar-foldBtn');

  foldBtn.addEventListener('click', (e) => {
    foldRoot.classList.toggle('ac--fold');
  });

  // sidebar menu
  const navItem = document.querySelectorAll('.sidebar-menu .menu-item');

  navItem.forEach((item) => {
    const btn = item.querySelector('.btn');
    btn.addEventListener('click', (e) => {
      item.classList.toggle('ac--active');
    });
  });

  // sitemap
  const menuCloseBtn = document.querySelector('.btn-sitemap-close');
  const menuRoot = document.querySelector('.console-header');
  const menuBg = document.querySelector('.console-header-bg');

  menuRoot.addEventListener('mouseenter', () => {
    menuRoot.classList.add('show');
    menuBg.style.height = '300px';
  });

  menuRoot.addEventListener('mouseleave', () => {
    menuRoot.classList.remove('show');
    menuBg.style.height = '0';
  });

  menuCloseBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    menuRoot.classList.remove('show');
    menuBg.style.height = '0';
  });
});
